package com.cg.mts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class MainDriver {

	public static void main(String[] args) {
		SpringApplication.run(MainDriver.class, args);

	}

}
