package com.cg.mts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mts.entities.Course;
import com.cg.mts.entities.UniversityStaffMember;
import com.cg.mts.exception.CourseNotFoundException;
import com.cg.mts.service.UniversityStaffServiceImpl;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping
public class UniversityStaffController {
	@Autowired(required = true )
	public UniversityStaffServiceImpl UniversityStaffServiceObject;
	
	
	@GetMapping("/universitystaff/{staffid}")
	private UniversityStaffMember viewStaff(@PathVariable int staffid) {
		return UniversityStaffServiceObject.viewStaff(staffid);
	}
	@GetMapping("/universitystaff")
	private List<UniversityStaffMember> viewAllStaffs()  {
		return UniversityStaffServiceObject.viewAllStaffs();
	}
	@PostMapping("/universitystaff/add")
	private UniversityStaffMember addStaff(@RequestBody UniversityStaffMember user) {
		return UniversityStaffServiceObject.addStaff(user);
	}
	@PostMapping("/universitystaff/update")
	private UniversityStaffMember updateStaff(@RequestBody UniversityStaffMember user) {
		return UniversityStaffServiceObject.updateStaff(user);
	}
	@PostMapping("/universitystaff/course/add")
	private Course addCourse(@RequestBody Course course)  {
		return UniversityStaffServiceObject.addCourse(course);
	}
	@PostMapping("/universitystaff/course/update")
	private Course updateCourse(@RequestBody Course course) throws CourseNotFoundException  {
		return UniversityStaffServiceObject.updateCourse(course);
	}
	@DeleteMapping("/universitystaff/del/{staffid}")
	private void removeStaff(@PathVariable int staffid) {
		UniversityStaffServiceObject.removeStaff(staffid);
	}
	@DeleteMapping("/universitystaff/course/{courseId}")
	private void removeCourse(@PathVariable int courseId) throws CourseNotFoundException {
		UniversityStaffServiceObject.removeCourse(courseId);
	}
}
