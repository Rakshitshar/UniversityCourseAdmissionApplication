package com.cg.mts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mts.entities.Login;
import com.cg.mts.repository.ILoginRepository;
@Service
public class LoginServiceImpl implements ILoginService{
	@Autowired
	public ILoginRepository ILoginRepositoryObject;
	

	@Override
	public boolean loginAsAdmissionCommiteeMember(String username, String password) {
		Login log =  ILoginRepositoryObject.findByUsername(username);
		boolean ot = false;
        if (log == null) {
        	ot = false;
        }
        else if(log.getPassword().equals(password)) {
        	ot = true;
        }
        return ot;
	}

	@Override
	public boolean loginAsUniversityStaffMember(String username, String password) {
		Login log =  ILoginRepositoryObject.findByUsername(username);
		boolean ot = false;
        if (log == null) {
        	ot = false;
        }
        else if(log.getPassword().equals(password)) {
        	ot = true;
        }
        return ot;
	}

	

}
