package com.cg.mts.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="applicant")
public class Applicant {
	@Id
	@Column(name="applicant_id")
	@GeneratedValue
	private int applicantId;
	@Column(name="applicant_name")
	private String applicantName;
	@Column(name="mobilenumber")
	private String mobileNumber;
	@Column(name="applicant_degree")
	private String applicantDegree;
	@Column(name="applicant_graduationpercent")
	private int applicantGraduationPercent;
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "admission_id")
	private Admission admission;
	@Enumerated(EnumType.ORDINAL)
	private AdmissionStatus status;
	public Applicant() {
		super();
	}
	
	public Applicant(int applicantId, String applicantName, String mobileNumber, String applicantDegree,
			int applicantGraduationPercent, Admission admission, AdmissionStatus status) {
		super();
		this.applicantId = applicantId;
		this.applicantName = applicantName;
		this.mobileNumber = mobileNumber;
		this.applicantDegree = applicantDegree;
		this.applicantGraduationPercent = applicantGraduationPercent;
		this.admission = admission;
		this.status = status;
	}
	
	public int getApplicantId() {
		return applicantId;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public String getApplicantDegree() {
		return applicantDegree;
	}
	public int getApplicantGraduationPercent() {
		return applicantGraduationPercent;
	}
	public Admission getAdmission() {
		return admission;
	}
	public AdmissionStatus getStatus() {
		return status;
	}
	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public void setApplicantDegree(String applicantDegree) {
		this.applicantDegree = applicantDegree;
	}
	public void setApplicantGraduationPercent(int applicantGraduationPercent) {
		this.applicantGraduationPercent = applicantGraduationPercent;
	}
	public void setAdmission(Admission admission) {
		this.admission = admission;
	}
	public void setStatus(AdmissionStatus status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "Applicant [applicantId=" + applicantId + ", applicantName=" + applicantName + ", mobileNumber="
				+ mobileNumber + ", applicantDegree=" + applicantDegree + ", applicantGraduationPercent="
				+ applicantGraduationPercent + ", admission=" + admission + ", status=" + status + "]";
	}
	
	
}
