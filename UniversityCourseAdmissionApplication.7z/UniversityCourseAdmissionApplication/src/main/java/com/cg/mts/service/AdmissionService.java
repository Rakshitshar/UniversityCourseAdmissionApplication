package com.cg.mts.service;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mts.entities.Admission;
import com.cg.mts.exception.AdmissionNotGrantedException;
import com.cg.mts.repository.IAdmissionRepository;

@Service
public class AdmissionService implements IAdmissionService{
	@Autowired
	public IAdmissionRepository IAdmissionRepositoryObject;
	
	
	public Admission addAdmission(Admission admission){
				return IAdmissionRepositoryObject.save(admission);
	}

	
	public Admission updateAdmission(Admission admission) throws AdmissionNotGrantedException {
		Admission ad=IAdmissionRepositoryObject.findById(admission.getAdmissionId()).orElseThrow(()->new AdmissionNotGrantedException("Admission id not found ::"));
		return IAdmissionRepositoryObject.save(ad);
	}

	
	public void cancelAdmission(int admissionId) throws AdmissionNotGrantedException {
		Admission ad=IAdmissionRepositoryObject.findById(admissionId).orElseThrow(()->new AdmissionNotGrantedException("Admission id not found ::"));
		IAdmissionRepositoryObject.deleteById(ad.getAdmissionId());
	}

	public List<Admission> findByCourseId(int courseId) {
		return IAdmissionRepositoryObject.findByCourseId(courseId);
	}


	public List<Admission> findByAdmissionDate(LocalDate admissionDate) {
		return IAdmissionRepositoryObject.findByAdmissionDate(admissionDate);
	}


	
	
}
