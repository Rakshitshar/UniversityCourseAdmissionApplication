package com.cg.mts.exception;

public class ApplicantNotFoundException extends Exception {
	public ApplicantNotFoundException (String e){
		super(e);
	}
}
