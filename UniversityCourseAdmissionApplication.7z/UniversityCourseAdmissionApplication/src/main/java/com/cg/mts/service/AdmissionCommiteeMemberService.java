package com.cg.mts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mts.entities.Admission;
import com.cg.mts.entities.AdmissionCommiteeMember;
import com.cg.mts.entities.AdmissionStatus;
import com.cg.mts.entities.Applicant;

import com.cg.mts.repository.IAdmissionCommiteeMemberRepository;
@Service
public class AdmissionCommiteeMemberService implements IAdmissionCommiteeMemberService{
	@Autowired
	public IAdmissionCommiteeMemberRepository  IAdmissionCommiteeMemberRepositoryObject;
	
	
	public AdmissionCommiteeMember addCommiteeMember(AdmissionCommiteeMember member) {
		return IAdmissionCommiteeMemberRepositoryObject.save(member);
	}

	
	public AdmissionCommiteeMember updateCommiteeMember(AdmissionCommiteeMember member) {
		return IAdmissionCommiteeMemberRepositoryObject.save(member);
	}

	
	public AdmissionCommiteeMember viewCommiteeMember(int adminId) {
		return IAdmissionCommiteeMemberRepositoryObject.findById(adminId).get();
	}

	
	public void removeCommiteeMember(int adminId) {
		IAdmissionCommiteeMemberRepositoryObject.deleteById(adminId);
	}

	
	public List<AdmissionCommiteeMember> viewAllCommiteeMembers() {
		return IAdmissionCommiteeMemberRepositoryObject.findAll();
	}

	
	public void provideAdmissionResult(Applicant applicant, Admission admission) {
		if(applicant.getApplicantGraduationPercent() >= 70) {
			applicant.setStatus(AdmissionStatus.Confirmed);
			admission.setStatus(AdmissionStatus.Confirmed);
		}
		else if(applicant.getApplicantGraduationPercent() >= 40) {
			applicant.setStatus(AdmissionStatus.Pending);
			admission.setStatus(AdmissionStatus.Pending);
		}
		else {
			applicant.setStatus(AdmissionStatus.Rejected);
			admission.setStatus(AdmissionStatus.Rejected);
		}
	}

}
