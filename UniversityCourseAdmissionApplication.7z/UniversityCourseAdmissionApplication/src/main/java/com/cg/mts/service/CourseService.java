package com.cg.mts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mts.entities.Course;
import com.cg.mts.exception.CourseNotFoundException;
import com.cg.mts.repository.ICourseRepository;
@Service
public class CourseService implements ICourseService{
	@Autowired
	public ICourseRepository ICourseRepositoryObject;
	
	
	public Course addCourse(Course course) {
		return ICourseRepositoryObject.save(course);
	}

	
	public void removeCourse(int courseId) throws CourseNotFoundException {
		Course cd=ICourseRepositoryObject.findById(courseId).orElseThrow(()->new CourseNotFoundException("Course id not found ::"));
		 ICourseRepositoryObject.deleteById(cd.getCourseId());
	}

	
	public Course updateCourse(Course course) throws CourseNotFoundException {
		Course cd=ICourseRepositoryObject.findById(course.getCourseId()).orElseThrow(()->new CourseNotFoundException("Course id not found ::"));
		return ICourseRepositoryObject.save(cd);
	}

	
	public Course viewCourse(int courseid) throws CourseNotFoundException {
		Course cd=ICourseRepositoryObject.findById(courseid).orElseThrow(()->new CourseNotFoundException("Course id not found ::"));
		return ICourseRepositoryObject.findById(cd.getCourseId()).get();
	}

	
	public List<Course> viewAllCourses() {
		return ICourseRepositoryObject.findAll();
	}

}
