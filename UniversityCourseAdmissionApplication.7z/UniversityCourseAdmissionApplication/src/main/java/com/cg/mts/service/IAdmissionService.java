package com.cg.mts.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.mts.entities.Admission;
import com.cg.mts.exception.AdmissionNotGrantedException;

@Service
public interface IAdmissionService {
	public Admission addAdmission(Admission admission);
	public Admission updateAdmission(Admission admission) throws AdmissionNotGrantedException;
	public void cancelAdmission(int admissionId) throws AdmissionNotGrantedException;
	public List<Admission> findByCourseId(int courseId);
	public List<Admission> findByAdmissionDate(LocalDate admissionDate);
	
	
}
