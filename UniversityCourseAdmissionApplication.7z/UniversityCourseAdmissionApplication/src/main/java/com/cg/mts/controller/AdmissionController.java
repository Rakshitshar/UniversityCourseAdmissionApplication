package com.cg.mts.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mts.entities.Admission;
import com.cg.mts.exception.AdmissionNotGrantedException;
import com.cg.mts.service.AdmissionService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping
public class AdmissionController {
	@Autowired(required = true )
	public AdmissionService AdmissionServiceObject;
	
	@GetMapping("/admission/{courseId}")
	private List<Admission> findByCourseId(@PathVariable int courseId) {
		return AdmissionServiceObject.findByCourseId(courseId);
	}
	
	@GetMapping("/admission/{admissionDate}")
	private List<Admission> findByAdmissionDate(@PathVariable LocalDate admissionDate){
		return AdmissionServiceObject.findByAdmissionDate(admissionDate);
	}
	
	@PostMapping("/admission/add")
	private Admission addAdmission(@RequestBody Admission admission) throws AdmissionNotGrantedException {
		return AdmissionServiceObject.addAdmission(admission);
	}
	
	@PostMapping("/admission/update")
	private Admission updateAdmission(@RequestBody Admission admission) throws AdmissionNotGrantedException {
		return AdmissionServiceObject.updateAdmission(admission);
	}
	
	@DeleteMapping("/admission/{admissionId}")
	private void cancelAdmission(@PathVariable int admissionId) throws AdmissionNotGrantedException {
		AdmissionServiceObject.cancelAdmission(admissionId);
	}
}
