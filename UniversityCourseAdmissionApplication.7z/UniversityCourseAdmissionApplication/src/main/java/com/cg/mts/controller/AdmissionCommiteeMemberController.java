package com.cg.mts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mts.entities.Admission;
import com.cg.mts.entities.AdmissionCommiteeMember;
import com.cg.mts.entities.Applicant;
import com.cg.mts.service.AdmissionCommiteeMemberService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping
public class AdmissionCommiteeMemberController {
	
	@Autowired(required = true )
	public AdmissionCommiteeMemberService AdmissionCommiteeMemberServiceObject;
	
	@GetMapping("/admissioncommiteemember")
	private List<AdmissionCommiteeMember> viewAllCommiteeMembers(){	
		return AdmissionCommiteeMemberServiceObject.viewAllCommiteeMembers();		
	}
	
	@GetMapping("/admissioncommiteemember/{adminId}")
	private AdmissionCommiteeMember getAdmissionCommiteeMemberById(@PathVariable int adminId){
	 return AdmissionCommiteeMemberServiceObject.viewCommiteeMember(adminId);
	}
	
	@PostMapping("/admissioncommiteemember/add" )
	private AdmissionCommiteeMember addCommiteeMember( @RequestBody AdmissionCommiteeMember member)
	{
		return AdmissionCommiteeMemberServiceObject.addCommiteeMember(member);
	}
	
	@PostMapping("/admissioncommiteemember/update" )
	private AdmissionCommiteeMember updateCommiteeMember( @RequestBody AdmissionCommiteeMember member)
	{
		return AdmissionCommiteeMemberServiceObject.updateCommiteeMember(member);
	}
	
	@DeleteMapping("/admissioncommiteemember/{adminId}")
	private void removeCommiteeMember(@PathVariable int adminId) {
		AdmissionCommiteeMemberServiceObject.removeCommiteeMember(adminId);
	}
	
	@GetMapping("/admissioncommiteemember/result")
	private void provideAdmissionResult(Applicant applicant, Admission admission) {
		AdmissionCommiteeMemberServiceObject.provideAdmissionResult(applicant, admission);
	}
}
