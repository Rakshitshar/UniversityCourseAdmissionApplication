package com.cg.mts.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="course")
public class Course {
	@Id
	@Column(name="course_id")
	@GeneratedValue
	private int courseId;
	@Column(name="course_name")
	private String courseName;
	@Column(name="course_duration")
	private String courseDuration;
	@Column(name="course_startdate")
	private LocalDate courseStartDate;
	@Column(name="course_enddate")
	private LocalDate courseEndDate;
	@Column(name="course_fees")
	private String courseFees;
	
	public Course() {
		super();
	}
	
	public Course(int courseId, String courseName, String courseDuration, LocalDate courseStartDate,
			LocalDate courseEndDate, String courseFees) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.courseDuration = courseDuration;
		this.courseStartDate = courseStartDate;
		this.courseEndDate = courseEndDate;
		this.courseFees = courseFees;
	}
	
	public int getCourseId() {
		return courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public String getCourseDuration() {
		return courseDuration;
	}
	public LocalDate getCourseStartDate() {
		return courseStartDate;
	}
	public LocalDate getCourseEndDate() {
		return courseEndDate;
	}
	public String getCourseFees() {
		return courseFees;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public void setCourseDuration(String courseDuration) {
		this.courseDuration = courseDuration;
	}
	public void setCourseStartDate(LocalDate courseStartDate) {
		this.courseStartDate = courseStartDate;
	}
	public void setCourseEndDate(LocalDate courseEndDate) {
		this.courseEndDate = courseEndDate;
	}
	public void setCourseFees(String courseFees) {
		this.courseFees = courseFees;
	}
	
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + ", courseDuration=" + courseDuration
				+ ", courseStartDate=" + courseStartDate + ", courseEndDate=" + courseEndDate + ", courseFees="
				+ courseFees + "]";
	}
	
	
	
}
