package com.cg.mts.exception;

public class LoginFailedException extends Exception {
	public LoginFailedException (String e){
		super(e);
	}
}
