package com.cg.mts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mts.entities.AdmissionStatus;
import com.cg.mts.entities.Applicant;
import com.cg.mts.exception.ApplicantNotFoundException;
import com.cg.mts.service.ApplicantService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping
public class ApplicantController {
	@Autowired(required = true )
	public ApplicantService ApplicantServiceObject;
	
	@GetMapping("/applicant/{applicantId}")
	private Applicant viewApplicant(@PathVariable int applicantId) throws ApplicantNotFoundException {
		return ApplicantServiceObject.viewApplicant(applicantId);
	}
	
	@GetMapping("/applicant/{status}")
	private List<Applicant> findByStatus(AdmissionStatus status) {
		return ApplicantServiceObject.findByStatus(status);
	}
	
	@DeleteMapping("/applicant/{applicantId}")
	private void deleteApplicant(int applicantId) throws ApplicantNotFoundException {
		ApplicantServiceObject.deleteApplicant(applicantId);
	}
	
	@PostMapping("/applicant/add")
	private Applicant addApplicant(@RequestBody Applicant applicant) {
		return ApplicantServiceObject.addApplicant(applicant);
	}
	
	@PostMapping("/applicant/update")
	private Applicant updateApplicant(@RequestBody Applicant applicant) throws ApplicantNotFoundException{
		return ApplicantServiceObject.updateApplicant(applicant);
	}
	
}
