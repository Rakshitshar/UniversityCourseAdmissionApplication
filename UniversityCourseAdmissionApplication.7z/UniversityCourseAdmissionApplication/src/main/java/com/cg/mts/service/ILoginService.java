package com.cg.mts.service;

import org.springframework.stereotype.Service;

@Service
public interface ILoginService {

	public boolean loginAsAdmissionCommiteeMember(String username,String password);
	public boolean loginAsUniversityStaffMember(String username,String password);
	
}
